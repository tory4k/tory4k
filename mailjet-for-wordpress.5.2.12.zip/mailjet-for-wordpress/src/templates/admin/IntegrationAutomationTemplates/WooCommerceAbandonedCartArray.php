<?php
return array(
    'tagName' => 'mjml',
    'children' =>
        array(
            0 =>
                array(
                    'tagName' => 'mj-body',
                    'children' =>
                        array(
                            0 =>
                                array(
                                    'tagName' => 'mj-section',
                                    'children' =>
                                        array(
                                            0 =>
                                                array(
                                                    'tagName' => 'mj-column',
                                                    'attributes' =>
                                                        array(
                                                            'passport' =>
                                                                array(
                                                                    'id' => 'TB_O38KWKT',
                                                                ),
                                                        ),
                                                    'children' =>
                                                        array(
                                                            0 =>
                                                                array(
                                                                    'tagName' => 'mj-text',
                                                                    'content' => '<p style="line-height: 45px; margin: 10px 0; text-align: left;"><span style="color:#555555"><b><span style="font-size:25px">Still thinking about it?</span></b></span></p>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'line-height' => '22px',
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#4e4e4e',
                                                                            'align' => 'left',
                                                                            'padding-bottom' => '0px',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'F_1VkT87As',
                                                                                ),
                                                                            'padding-top' => '0px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => 'ouXxSI7c5n2UE',
                                                                ),
                                                            1 =>
                                                                array(
                                                                    'tagName' => 'mj-text',
                                                                    'content' => '<p style="line-height: 21px; margin: 10px 0; text-align: left;"><span style="font-size:14px">We see you left something in your cart.</span></p><p style="line-height: 21px; margin: 10px 0; text-align: left;"><span style="font-size:14px">You are just a few clicks away from completing your purchase.&nbsp;Would you like to do it now?</span></p>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'line-height' => '22px',
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#4e4e4e',
                                                                            'align' => 'left',
                                                                            'padding-bottom' => '0px',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'dtQ2S8a1Gh',
                                                                                ),
                                                                            'padding-top' => '0px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => 'uEUQOdhdigih7',
                                                                ),
                                                            2 =>
                                                                array(
                                                                    'tagName' => 'mj-text',
                                                                    'content' => '<p style="margin: 10px 0; text-align: left;"><span style="color:#555555"><b><span style="font-size:18px">Your cart</span></b></span></p>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'line-height' => '22px',
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#4e4e4e',
                                                                            'align' => 'left',
                                                                            'padding-bottom' => '0px',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'idMaOK4L7i',
                                                                                ),
                                                                            'padding-top' => '10px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => '0SZ5QK-NnRhXJ',
                                                                ),
                                                            3 =>
                                                                array(
                                                                    'tagName' => 'mj-dev',
                                                                    'content' => '{% for product in var:products %}',
                                                                    'attributes' =>
                                                                        array(
                                                                            'padding' => '0',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'krSJSF1Df',
                                                                                ),
                                                                        ),
                                                                    'id' => 'oprlVKUwwOteG',
                                                                ),
                                                            4 =>
                                                                array(
                                                                    'tagName' => 'mj-divider',
                                                                    'attributes' =>
                                                                        array(
                                                                            'border-color' => '#e6e6e6',
                                                                            'border-style' => 'solid',
                                                                            'border-width' => '1px',
                                                                            'padding' => '10px 25px',
                                                                            'width' => '100%',
                                                                            'padding-top' => '0px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => '9e7RJG7J8Qy',
                                                                                ),
                                                                            'padding-bottom' => '0px',
                                                                        ),
                                                                    'id' => '7hmF0f7MPlnDI',
                                                                ),
                                                        ),
                                                    'id' => '0EzBzwXcRDJf-',
                                                ),
                                        ),
                                    'attributes' =>
                                        array(
                                            'background-repeat' => 'repeat',
                                            'padding' => '20px 0',
                                            'text-align' => 'center',
                                            'vertical-align' => 'top',
                                            'background-color' => '#ffffff',
                                            'padding-bottom' => '0px',
                                            'passport' =>
                                                array(
                                                    'name' => 'head',
                                                    'id' => 'S_5WPKa-Q-91',
                                                ),
                                        ),
                                    'id' => 'j8fIZGIZAOPzb',
                                ),
                            1 =>
                                array(
                                    'tagName' => 'mj-section',
                                    'children' =>
                                        array(
                                            0 =>
                                                array(
                                                    'tagName' => 'mj-column',
                                                    'attributes' =>
                                                        array(
                                                            'width' => '25%',
                                                            'passport' =>
                                                                array(
                                                                    'id' => 'jYd6duS4ej',
                                                                ),
                                                        ),
                                                    'children' =>
                                                        array(
                                                            0 =>
                                                                array(
                                                                    'tagName' => 'mj-image',
                                                                    'attributes' =>
                                                                        array(
                                                                            'padding-right' => '25px',
                                                                            'padding-left' => '25px',
                                                                            'src' => '{{product.image}}',
                                                                            'align' => 'center',
                                                                            'height' => 'auto',
                                                                            'padding-bottom' => '10px',
                                                                            'alt' => '{{product.title}}',
                                                                            'href' => '',
                                                                            'border' => 'none',
                                                                            'padding' => '10px 25px 10px 25px',
                                                                            'target' => '_blank',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'RQAzPee4o',
                                                                                    'mode' => 'image',
                                                                                ),
                                                                            'title' => '',
                                                                            'padding-top' => '10px',
                                                                        ),
                                                                    'id' => 'EVpQ-uV4a_3H8',
                                                                ),
                                                        ),
                                                    'id' => '2lAkhhMnb8lt_',
                                                ),
                                            1 =>
                                                array(
                                                    'tagName' => 'mj-column',
                                                    'attributes' =>
                                                        array(
                                                            'width' => '50%',
                                                            'passport' =>
                                                                array(
                                                                    'id' => 'nXpkbakLwD',
                                                                ),
                                                        ),
                                                    'children' =>
                                                        array(
                                                            0 =>
                                                                array(
                                                                    'tagName' => 'mj-text',
                                                                    'content' => '<p style="margin: 10px 0;"><span style="color:#555555"><b><span style="font-size:14px">{{product.title}}</span></b></span></p><p style="margin: 10px 0;"><span style="font-size:14px">{{product.variant_title}}</span></p><p style="margin: 10px 0;"><span style="color:#555555"><span style="font-size:14px">Quantity: {{product.quantity}}</span></span></p>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'line-height' => '24px',
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#4e4e4e',
                                                                            'align' => 'left',
                                                                            'padding-bottom' => '0px',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'qaynr6W5O',
                                                                                ),
                                                                            'padding-top' => '0px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => '9BJnKTTRIbuOgZ',
                                                                ),
                                                        ),
                                                    'id' => '5Ocj_ok9mkQgqU',
                                                ),
                                            2 =>
                                                array(
                                                    'tagName' => 'mj-column',
                                                    'attributes' =>
                                                        array(
                                                            'width' => '25%',
                                                            'passport' =>
                                                                array(
                                                                    'id' => 'bNk8beO8sH',
                                                                ),
                                                        ),
                                                    'children' =>
                                                        array(
                                                            0 =>
                                                                array(
                                                                    'tagName' => 'mj-text',
                                                                    'content' => '<p style="margin: 10px 0;"><span style="color:#555555"><span style="font-size:14px">{{product.price}}</span></span></p>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'line-height' => '24px',
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#4e4e4e',
                                                                            'align' => 'left',
                                                                            'padding-bottom' => '0px',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => '5FqGXlB-6',
                                                                                ),
                                                                            'padding-top' => '0px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => 'rRssNM6kzGjCKv',
                                                                ),
                                                        ),
                                                    'id' => 'ANBWbOALN29Vai',
                                                ),
                                        ),
                                    'attributes' =>
                                        array(
                                            'background-repeat' => 'repeat',
                                            'padding' => '20px 0',
                                            'text-align' => 'center',
                                            'vertical-align' => 'top',
                                            'passport' =>
                                                array(
                                                    'id' => 'mOyoP86zT',
                                                ),
                                            'padding-top' => '10px',
                                            'padding-bottom' => '10px',
                                            'background-color' => '#ffffff',
                                        ),
                                    'id' => 'dGLcjYGOkmnco',
                                ),
                            2 =>
                                array(
                                    'tagName' => 'mj-section',
                                    'children' =>
                                        array(
                                            0 =>
                                                array(
                                                    'tagName' => 'mj-column',
                                                    'attributes' =>
                                                        array(
                                                            'passport' =>
                                                                array(
                                                                    'id' => 'YZCgDkiHox',
                                                                ),
                                                        ),
                                                    'children' =>
                                                        array(
                                                            0 =>
                                                                array(
                                                                    'tagName' => 'mj-dev',
                                                                    'content' => '{% endfor %}',
                                                                    'attributes' =>
                                                                        array(
                                                                            'padding' => '0',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'N0n2Bm398',
                                                                                ),
                                                                        ),
                                                                    'id' => 'jqqLgFhdU4xoN0',
                                                                ),
                                                            1 =>
                                                                array(
                                                                    'tagName' => 'mj-divider',
                                                                    'attributes' =>
                                                                        array(
                                                                            'border-color' => '#E6E6E6',
                                                                            'border-style' => 'solid',
                                                                            'border-width' => '1px',
                                                                            'padding' => '10px 25px',
                                                                            'width' => '100%',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'U0_ClSDw9',
                                                                                ),
                                                                            'padding-top' => '0px',
                                                                            'padding-bottom' => '0px',
                                                                        ),
                                                                    'id' => 'bcf0bbe0bO0Wip',
                                                                ),
                                                        ),
                                                    'id' => 'NypxqeNXeXxEPg',
                                                ),
                                        ),
                                    'attributes' =>
                                        array(
                                            'background-repeat' => 'repeat',
                                            'padding' => '20px 0',
                                            'text-align' => 'center',
                                            'vertical-align' => 'top',
                                            'passport' =>
                                                array(
                                                    'id' => 'Yj_5R_lwD',
                                                ),
                                            'padding-top' => '0px',
                                            'padding-bottom' => '0px',
                                            'background-color' => '#ffffff',
                                        ),
                                    'id' => 'hgFSOd6SUimIPM',
                                ),
                            3 =>
                                array(
                                    'tagName' => 'mj-section',
                                    'children' =>
                                        array(
                                            0 =>
                                                array(
                                                    'tagName' => 'mj-column',
                                                    'attributes' =>
                                                        array(
                                                            'passport' =>
                                                                array(
                                                                    'id' => 'j0lmah361j',
                                                                ),
                                                        ),
                                                    'children' =>
                                                        array(
                                                            0 =>
                                                                array(
                                                                    'tagName' => 'mj-button',
                                                                    'content' => '<b>Resume your order &gt;</b>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#ffffff',
                                                                            'background-color' => '#555',
                                                                            'align' => 'left',
                                                                            'href' => '{{var:abandoned_cart_link}}',
                                                                            'border' => 'none',
                                                                            'text-transform' => 'none',
                                                                            'vertical-align' => 'middle',
                                                                            'text-decoration' => 'none',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'U9JQFV8EK',
                                                                                ),
                                                                            'border-radius' => '3px',
                                                                            'font-weight' => 'normal',
                                                                            'inner-padding' => '10px 25px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => 'KXDPvJ0M5oKoDx',
                                                                ),
                                                            1 =>
                                                                array(
                                                                    'tagName' => 'mj-text',
                                                                    'content' => '<p style="line-height: 21px; margin: 10px 0; text-align: left;"><span style="font-size:14px">Best regards,</span></p><p style="line-height: 21px; margin: 10px 0; text-align: left;"><span style="font-size:14px">{{var:store_name}} staff</span></p>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'line-height' => '22px',
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#4e4e4e',
                                                                            'align' => 'left',
                                                                            'padding-bottom' => '40px',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'kbOjkLqu2H',
                                                                                ),
                                                                            'padding-top' => '10px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => 'D1RkjwNgC12vW7',
                                                                ),
                                                        ),
                                                    'id' => 'OVsbiRSqRLcVH-',
                                                ),
                                        ),
                                    'attributes' =>
                                        array(
                                            'background-repeat' => 'repeat',
                                            'padding' => '20px 0',
                                            'text-align' => 'center',
                                            'vertical-align' => 'top',
                                            'background-color' => '#ffffff',
                                            'padding-bottom' => '0px',
                                            'passport' =>
                                                array(
                                                    'name' => 'head',
                                                    'id' => 'sfnVk4THm',
                                                ),
                                            'padding-top' => '10px',
                                        ),
                                    'id' => '8r8UEeiA_6kV9A',
                                ),
                            4 =>
                                array(
                                    'tagName' => 'mj-section',
                                    'children' =>
                                        array(
                                            0 =>
                                                array(
                                                    'tagName' => 'mj-column',
                                                    'attributes' =>
                                                        array(
                                                            'passport' =>
                                                                array(
                                                                    'id' => 'pa4S1gtc5v',
                                                                ),
                                                        ),
                                                    'children' =>
                                                        array(
                                                            0 =>
                                                                array(
                                                                    'tagName' => 'mj-text',
                                                                    'content' => '<p style="line-height: 25px; text-align: center; margin: 10px 0;"><span style="color:#555555"><span style="font-size:12px">This email was sent to you by {{var:store_name}} -&nbsp;{{var:store_address}}</span></span></p>',
                                                                    'attributes' =>
                                                                        array(
                                                                            'line-height' => '22px',
                                                                            'font-family' => 'Arial, sans-serif',
                                                                            'color' => '#4e4e4e',
                                                                            'align' => 'left',
                                                                            'padding-bottom' => '10px',
                                                                            'container-background-color' => 'transparent',
                                                                            'padding' => '10px 25px',
                                                                            'passport' =>
                                                                                array(
                                                                                    'id' => 'IhNECkaGvg',
                                                                                ),
                                                                            'padding-top' => '10px',
                                                                            'font-size' => '13px',
                                                                        ),
                                                                    'id' => 'js1iuJ1OUkhH0N',
                                                                ),
                                                        ),
                                                    'id' => '9evTrnw7JT2WUj',
                                                ),
                                        ),
                                    'attributes' =>
                                        array(
                                            'background-color' => 'transparent',
                                            'text-align' => 'center',
                                            'padding-bottom' => '0px',
                                            'vertical-align' => 'top',
                                            'padding' => '20px 0',
                                            'passport' =>
                                                array(
                                                    'name' => 'head',
                                                    'version' => '4.3.0',
                                                    'id' => 'CjnsOa1Zs',
                                                ),
                                            'padding-top' => '0px',
                                            'background-repeat' => 'repeat',
                                        ),
                                    'id' => 'M3HkNv_jgVt9dz',
                                ),
                        ),
                    'attributes' =>
                        array(
                            'background-color' => '#f2f2f2',
                            'color' => '#4e4e4e',
                            'font-family' => 'Arial, sans-serif',
                            'passport' =>
                                array(
                                    'id' => 'pu_i0pvjS',
                                ),
                        ),
                    'id' => 'KGijqwV-KLHya',
                ),
        ),
    'attributes' =>
        array(
            'version' => '4.3.0',
            'owa' => 'desktop',
        ),
    'id' => 'aSfPlKGS_H-Tj',
);